# wm-tarifas
Plugin de WordPress para crear un panel de administración sencilla de tarifas.
