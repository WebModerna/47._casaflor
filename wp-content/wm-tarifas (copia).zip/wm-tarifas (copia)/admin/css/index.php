<?php
/*
Si el silencio es oro;
entontes,
el ruido es una ganga.
*/